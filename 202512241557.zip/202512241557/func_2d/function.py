
import os

import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm

import cfg
from conf import settings
from func_2d.utils import *
import pandas as pd


args = cfg.parse_args()

GPUdevice = torch.device('cuda', args.gpu_device)
pos_weight = torch.ones([1]).cuda(device=GPUdevice)*2
criterion_G = torch.nn.BCEWithLogitsLoss(pos_weight=pos_weight)
mask_type = torch.float32

torch.backends.cudnn.benchmark = True


def train_sam(args, net: nn.Module, optimizer, train_loader, epoch, writer):
    # use bfloat16 for the entire notebook
    torch.autocast(device_type="cuda", dtype=torch.bfloat16).__enter__()

    if torch.cuda.get_device_properties(0).major >= 8:
        # turn on tfloat32 for Ampere GPUs
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    # train mode
    net.train()
    optimizer.zero_grad()

    # init
    epoch_loss = 0
    lossfunc = criterion_G
    feat_sizes = [(256, 256), (128, 128), (64, 64)]

    with tqdm(total=len(train_loader), desc=f'Epoch {epoch}', unit='img') as pbar:
        for ind, pack in enumerate(train_loader):
            
            # --- 1. Prepare Data ---
            # Support Set
            support_imgs = pack['support_image'].to(dtype = mask_type, device = GPUdevice)
            support_masks = pack['support_mask'].to(dtype = mask_type, device = GPUdevice)
            # support_masks: [B, 1, H, W] -> need to check if memory encoder expects [B, 1, H, W] or [B, H, W]
            
            # Query Set
            query_imgs = pack['query_image'].to(dtype = mask_type, device = GPUdevice)
            query_masks = pack['query_mask'].to(dtype = mask_type, device = GPUdevice)
            
            # Query Prompts (Optional)
            if 'query_pt' in pack:
                pt_temp = pack['query_pt'].to(device = GPUdevice)
                pt = pt_temp.unsqueeze(1) # [B, 1, 2]
                point_labels_temp = pack['query_p_label'].to(device = GPUdevice)
                point_labels = point_labels_temp.unsqueeze(1) # [B, 1]
                
                coords_torch = torch.as_tensor(pt, dtype=torch.float, device=GPUdevice)
                labels_torch = torch.as_tensor(point_labels, dtype=torch.int, device=GPUdevice)
            else:
                coords_torch = None
                labels_torch = None
                
            
            # =================================================================================================
            # STEP 1: Process Support Set (Encode Memory)
            # =================================================================================================
            
            # 1. Image Encoder (Support)
            backbone_out_support = net.forward_image(support_imgs)
            _, vision_feats_support, vision_pos_embeds_support, _ = net._prepare_backbone_features(backbone_out_support)
            
            # --- Apply Adapter (if exists) ---
            if hasattr(net, 'adapter_model'):
                 vision_feats_support = net.adapter_model.adapt_features(vision_feats_support)
            
            # 2. Encode Mask Memory
            # For support set, we use the GT mask to create a memory
            # The mask should be resized to high_res_multimasks size usually, but let's check _encode_new_memory signature
            # It expects pred_masks_high_res.
            
            # We need to resize support_masks to image_size (1024) if it's not already
            # pack['support_mask'] is already resized to args.out_size (1024) in dataset
            
            # CRITICAL FIX: Binarize Support Mask
            # If support mask is not binary (e.g. 0-255 or interpolated), memory will be corrupted.
            support_masks = (support_masks > 0.5).float()
            
            # _encode_new_memory expects [B, 1, H, W]
            maskmem_features, maskmem_pos_enc = net._encode_new_memory(
                current_vision_feats=vision_feats_support,
                feat_sizes=feat_sizes,
                pred_masks_high_res=support_masks, 
                is_mask_from_pts=True # Treat GT as high-confidence "prediction"
            )
            
            # Prepare Memory Bank
            # We constructed a temporary memory bank just for this query
            # Format: list of [maskmem_features, maskmem_pos_enc, iou_pred, image_embed]
            
            # We also need image_embed for memory attention
            # Let's get image embedding for support image
            # We need to run the full pipeline to get image_embed?
            # Actually, `vision_feats_support[-1]` is the low-res feature map, but `net.sam_mask_decoder` uses `image_embeddings`.
            # Wait, `net._prepare_backbone_features` returns `vision_feats`.
            # In `train_sam`, `image_embed` is derived from `feats[-1]`.
            
            # Let's manually construct `image_embed` for support
            B = vision_feats_support[-1].size(1)
            feats_support = [feat.permute(1, 2, 0).view(B, -1, *feat_size) 
                     for feat, feat_size in zip(vision_feats_support[::-1], feat_sizes[::-1])][::-1]
            image_embed_support = feats_support[-1]

            # Construct Memory List
            # [maskmem_features, maskmem_pos_enc, score, image_embed]
            # score can be 1.0 since it is GT
            
            maskmem_features = maskmem_features.to(torch.bfloat16).to(device=GPUdevice, non_blocking=True)
            maskmem_pos_enc = maskmem_pos_enc[0].to(torch.bfloat16).to(device=GPUdevice, non_blocking=True)
            
            memory_bank_list = []
            for batch in range(B):
                memory_bank_list.append([
                    maskmem_features[batch].unsqueeze(0).detach(),
                    maskmem_pos_enc[batch].unsqueeze(0).detach(),
                    torch.tensor(1.0, device=GPUdevice), # High confidence for GT
                    image_embed_support[batch].reshape(-1).detach()
                ])

            # =================================================================================================
            # STEP 2: Process Query Set (Predict with Memory)
            # =================================================================================================
            
            # 1. Image Encoder (Query)
            backbone_out_query = net.forward_image(query_imgs)
            _, vision_feats_query, vision_pos_embeds_query, _ = net._prepare_backbone_features(backbone_out_query)
            
            # 2. Memory Attention
            # Attend to Support Memory
            
            to_cat_memory = []
            to_cat_memory_pos = []
            to_cat_image_embed = []
            
            for element in memory_bank_list:
                to_cat_memory.append((element[0]).cuda(non_blocking=True).flatten(2).permute(2, 0, 1))
                to_cat_memory_pos.append((element[1]).cuda(non_blocking=True).flatten(2).permute(2, 0, 1))
                to_cat_image_embed.append((element[3]).cuda(non_blocking=True))

            memory_stack = torch.stack(to_cat_memory, dim=0)
            memory_pos_stack = torch.stack(to_cat_memory_pos, dim=0)
            image_embed_stack = torch.stack(to_cat_image_embed, dim=0)
            
            # Correct reshaping:
            # memory_stack: [B, C, H, W] (after squeezing list dim)
            # memory = memory_stack.flatten(2).permute(2, 0, 1) # [H*W, B, C]
            
            memory = memory_stack.squeeze(1).flatten(2).permute(2, 0, 1)
            memory_pos = memory_pos_stack.squeeze(1).flatten(2).permute(2, 0, 1)

            # --- Fix Shape Mismatch ---
            # RuntimeError: Expected size for first two dimensions of batch2 tensor to be: [2, 4096] but got: [2, 64].
            # This suggests that `memory_attention` expects `memory` to be [B, L, C] or similar, 
            # OR `vision_feats_query` (curr) has incompatible shape.
            
            # Original code in `train_sam`:
            # vision_feats[-1] shape from `net._prepare_backbone_features`: [4096, B, 256] (L, B, C)
            # memory from `train_sam` (original): [4096*16, B, 64]? No.
            
            # Let's check `net.memory_attention` implementation details or typical usage.
            # In original `train_sam`:
            # memory = memory_stack_ori_new.reshape(-1, memory_stack_ori_new.size(2), memory_stack_ori_new.size(3))
            # memory_stack_ori_new shape: [B, 16, 64, 64, 64] -> permute -> [B, 64, 16, 64, 64] ?
            # Original: memory_stack_ori_new = (memory_stack_ori[sampled_indices].squeeze(3).permute(1, 2, 0, 3))
            # Sampled indices selects 16 memories.
            # Let's assume memory shape is [L_mem, B, C].
            
            # The error says "Expected size... [2, 4096] but got [2, 64]". 
            # 2 is batch size B. 4096 is H*W (64*64). 64 is Channel dim C.
            # It seems it's doing matrix multiplication (Linear layer or MatMul).
            # Likely `self.k_proj(k)` where k comes from memory.
            
            # If `k` is [B, L, C], Linear(C, C_out) works on last dim.
            # If `k` is [L, B, C], Linear works on last dim.
            
            # The error "Expected [2, 4096] but got [2, 64]" in `F.linear(input, self.weight, self.bias)`
            # suggests `input` has shape [..., 64] and weight expects 4096?
            # Or `input` is [2, 64] but expected [2, 4096]? 
            # Wait, 4096 is typically the sequence length (64x64).
            
            # Let's look at `memory_attention` call in `train_sam` original:
            # memory = memory_stack_ori_new.reshape(-1, memory_stack_ori_new.size(2), memory_stack_ori_new.size(3))
            # It reshapes to [-1, C, H, W]? Or [-1, H, W]?
            
            # Let's Try to match the shape expected by `sam2` memory attention.
            # It seems SAM2 expects memory to be flattened spatial dimensions?
            
            # If we look at the error stack trace:
            # File "/root/autodl-tmp/Medical-SAM2-main/sam2_train/modeling/sam/transformer.py", line 293, in forward
            # k = self.k_proj(k)
            # RuntimeError: Expected size for first two dimensions of batch2 tensor to be: [2, 4096] but got: [2, 64].
            
            # Wait, `k_proj` is usually `Linear(in_features, out_features)`.
            # If `k` is [L, B, C], and `k_proj` expects C channels.
            # If the error is about "batch2 tensor", maybe it's `torch.bmm` or Attention?
            # But the trace says `F.linear`.
            
            # Let's reconsider `memory` shape.
            # Our `memory` is [4096, 2, 64] (L, B, C).
            # If `memory_attention` treats first dim as Batch? No, typically L.
            
            # Let's try to permute memory to [B, L, C] ? Or [L, B, C] is correct?
            # In `train_sam` original:
            # memory_stack_ori_new: [B, 16, 64, 64, 64] (Batch, NumMem, C, H, W)
            # permute(1, 2, 0, 3) -> [16, 64, B, 64] ? No.
            
            # Let's simplify. We have 1 memory frame per batch item.
            # memory_stack: [B, 1, 64, 64, 64]
            # We want [L, B, C] where L = 64*64 = 4096.
            # memory = memory_stack.squeeze(1).flatten(2).permute(2, 0, 1) -> [4096, B, 64]
            
            # This looks correct for standard transformer [Seq, Batch, Dim].
            # BUT, maybe `memory_attention` in SAM2 does something different.
            
            # The error might be because `curr` (query) and `memory` (key/value) have mismatched dimensions that confuse the attention mechanism.
            # `curr` is `vision_feats_query[-1]`. Shape: [4096, B, 256].
            # `memory` is [4096, B, 64].
            # Channel dims mismatch! Query 256 vs Memory 64.
            # SAM2 memory feature dimension is 64. 
            # Vision feature dimension (stage 3) is 256.
            # The memory attention likely projects them to same space.
            
            # Wait, looking at `train_sam` original code again:
            # memory_stack_ori_new = (memory_stack_ori[sampled_indices].squeeze(3).permute(1, 2, 0, 3))
            # memory = memory_stack_ori_new.reshape(-1, memory_stack_ori_new.size(2), memory_stack_ori_new.size(3))
            
            # memory_stack_ori: [B, 16, 64, 64, 64] (from to_cat_memory which is flattened(2).permute(2,0,1)? No)
            # In `train_sam`:
            # to_cat_memory.append((element[0])...flatten(2).permute(2, 0, 1)) -> [4096, 1, 64]
            # memory_stack_ori = torch.stack(to_cat_memory, dim=0) -> [N_mem, 4096, 1, 64] ??
            
            # Let's trace `train_sam` original `to_cat_memory`:
            # element[0] is maskmem_features: [1, 64, 64, 64] (B=1 per element)
            # element[0].flatten(2).permute(2, 0, 1) -> [4096, 1, 64]
            # to_cat_memory list of [4096, 1, 64].
            # memory_stack_ori = torch.stack -> [N_mem, 4096, 1, 64]
            
            # Then `sampled_indices` [B, 16].
            # This part is complex in original code because it handles shared memory bank.
            # But we have 1-to-1 memory.
            
            # The key is: `memory` passed to `memory_attention` must have shape compatible with `curr`.
            # In original: `memory` seems to be reshaped to [-1, 64, 64]?
            # If `memory_attention` expects 2D spatial memory, we should provide that.
            
            # Let's try to match the expected input of `memory_attention`.
            # If `memory_attention` takes `memory` and `memory_pos`.
            # `memory` usually is [B, C, H, W] or [B*N, C, H, W] if it handles 2D attention.
            # OR [L, B, C].
            
            # Let's look at `_encode_new_memory` output: `maskmem_features` is [B, 64, 64, 64].
            # We want to feed this into `memory_attention`.
            # Our `memory_stack` is [B, 1, 64, 64, 64].
            # We squeeze to [B, 64, 64, 64].
            
            # If we simply flatten H,W: [B, 64, 4096]. Permute to [4096, B, 64].
            # This is what we did.
            
            # Maybe the issue is `memory_attention` expects ALL memories concatenated in Batch dim?
            # i.e. [L, B*N_mem, C].
            # We have N_mem=1. So [L, B, C].
            
            # Let's look at the error again: "Expected [2, 4096] but got [2, 64]".
            # 2 is Batch. 
            # If `Linear` expects 4096, it means the channel dim is 4096? That's weird.
            # Unless `k` is [B, C, L] -> [2, 64, 4096]. And `Linear` expects last dim 4096?
            # Usually Linear is applied to Channel dim.
            
            # Wait, `memory_attention` in SAM2 might be using `RoPE` (Rotary Positional Embedding) or 2D attention which expects `(B, C, H, W)`?
            
            # Let's try passing `memory` as `(B*N, C, H, W)` or `(N*B, H*W, C)`?
            
            # In `train_sam`:
            # memory = memory_stack_ori_new.reshape(-1, memory_stack_ori_new.size(2), memory_stack_ori_new.size(3))
            # memory_stack_ori_new shape was [B, 16, 64, 64, 64] ? No.
            # It was derived from `to_cat_memory` which was [4096, 1, 64].
            
            # Let's re-read `train_sam` logic CAREFULLY.
            # `to_cat_memory` elements are [4096, 1, 64].
            # `memory_stack_ori` = stack -> [N, 4096, 1, 64].
            # `memory_stack_ori_new` = index select...
            # The reshaping logic in `train_sam` is extremely confusing without knowing exact dims.
            
            # Let's look at `validation_sam` which WORKED for 1 batch?
            # No, validation failed with unpacking error, so it ran inference successfully!
            # In `validation_sam`:
            # memory = memory_bank_list[0][0].cuda(non_blocking=True).flatten(2).permute(2, 0, 1) # [4096, 1, 64]
            # memory = memory.expand(-1, B, -1) # [4096, B, 64]
            # This worked!
            
            # So why `train_sam` fails?
            # In `train_sam`:
            # memory = memory_stack.squeeze(1).flatten(2).permute(2, 0, 1)
            # memory_stack is [B, 1, 64, 64, 64].
            # squeeze(1) -> [B, 64, 64, 64].
            # flatten(2) -> [B, 64, 4096].
            # permute(2, 0, 1) -> [4096, B, 64].
            
            # It SHOULD be the same shape [4096, 2, 64] (B=2).
            # Why did it fail with "Expected [2, 4096] but got [2, 64]"?
            
            # Ah! `permute(2, 0, 1)` on `[B, 64, 4096]` (dim 0, 1, 2)
            # 2->4096, 0->B, 1->64.
            # Result: [4096, B, 64]. This is correct.
            
            # Maybe `memory_stack` wasn't [B, 1, 64, 64, 64]?
            # `to_cat_memory` append `element[0]`.
            # `element[0]` is `maskmem_features[batch].unsqueeze(0)`.
            # `maskmem_features` is [B, 64, 64, 64].
            # `element[0]` is [1, 64, 64, 64].
            # `to_cat_memory` is list of B tensors of [1, 64, 64, 64].
            # `to_cat_memory` append `...flatten(2).permute(2, 0, 1)`.
            # [1, 64, 64, 64] flatten(2) -> [1, 64, 4096]. permute(2, 0, 1) -> [4096, 1, 64].
            
            # `memory_stack` = stack(to_cat_memory) -> [B, 4096, 1, 64].
            # THIS IS THE DIFFERENCE.
            # In my thought process I assumed `to_cat_memory` was not flattened/permuted yet.
            # But code says: `to_cat_memory.append((element[0])...flatten(2).permute(2, 0, 1))`
            
            # So `memory_stack` is [B, 4096, 1, 64].
            
            # My `memory` construction line:
            # memory = memory_stack.squeeze(1).flatten(2).permute(2, 0, 1)
            # Input: [B, 4096, 1, 64].
            # squeeze(1): Error? No, dim 1 is 4096.
            # If I intended to squeeze the "1" (which is dim 2), I should use squeeze(2).
            
            # BUT wait, `train_sam` logic:
            # `for element in memory_bank_list:` -> `element` is ONE memory sample [1, 64, 64, 64] etc.
            # `to_cat_memory.append` -> adds [4096, 1, 64].
            # `memory_stack` -> [B, 4096, 1, 64].
            
            # We want to combine these into [4096, B, 64].
            # We just need to cat them along dim 1?
            # Or stack and reshape.
            
            # memory_stack [B, 4096, 1, 64].
            # permute to [4096, B, 1, 64]?
            # memory_stack.permute(1, 0, 2, 3) -> [4096, B, 1, 64].
            # squeeze(2) -> [4096, B, 64].
            
            # My previous code:
            # memory = memory_stack.squeeze(1).flatten(2).permute(2, 0, 1)
            # If input is [B, 4096, 1, 64].
            # squeeze(1) -> [B, 1, 64] (Squeezes 4096??? No, squeeze removes dim of size 1).
            # If I call squeeze(1), and dim 1 is 4096, it does nothing (unless 4096=1).
            # So it remains [B, 4096, 1, 64].
            # flatten(2) -> [B, 4096, 64].
            # permute(2, 0, 1) -> [64, B, 4096].
            
            # THIS IS WRONG. Shape became [64, 2, 4096].
            # "Expected [2, 4096] but got [2, 64]" (Batch=2).
            # It seems it expected [B, 4096] but got [B, 64] in the last dimension?
            # If shape is [64, 2, 4096].
            # Maybe `Linear` was applied on `4096` dim? 
            # Or maybe `k_proj` expects 64 channels, but got 4096?
            
            # Anyway, the fix is to properly reshape [B, 4096, 1, 64] to [4096, B, 64].
            
            memory = memory_stack.permute(1, 0, 2, 3).squeeze(2) # [4096, B, 64]
            memory_pos = memory_pos_stack.permute(1, 0, 2, 3).squeeze(2) # [4096, B, 64]
            
            # Apply Memory Attention
            vision_feats_query[-1] = net.memory_attention(
                curr=[vision_feats_query[-1]],
                curr_pos=[vision_pos_embeds_query[-1]],
                memory=memory,
                memory_pos=memory_pos,
                num_obj_ptr_tokens=0
            )
            
            # 3. Prompt Encoder (Query)
            # Implement Random Prompt Dropout
            # 10% chance to drop points (instead of 50%) to stabilize training
            if random.random() < 0.3:
                points = None
            else:
                points = (coords_torch, labels_torch)
                
            se, de = net.sam_prompt_encoder(
                points=points,
                boxes=None,
                masks=None,
                batch_size=B,
            )
            
            # 4. Mask Decoder
            feats_query = [feat.permute(1, 2, 0).view(B, -1, *feat_size) 
                     for feat, feat_size in zip(vision_feats_query[::-1], feat_sizes[::-1])][::-1]
            image_embed_query = feats_query[-1]
            high_res_feats_query = feats_query[:-1]
            
            low_res_multimasks, iou_predictions, sam_output_tokens, object_score_logits = net.sam_mask_decoder(
                image_embeddings=image_embed_query,
                image_pe=net.sam_prompt_encoder.get_dense_pe(),
                sparse_prompt_embeddings=se,
                dense_prompt_embeddings=de,
                multimask_output=False,
                repeat_image=False,
                high_res_features=high_res_feats_query
            )
            
            # =================================================================================================
            # STEP 3: Loss Calculation
            # =================================================================================================
            
            # Resize prediction
            pred = F.interpolate(low_res_multimasks, size=(args.out_size, args.out_size))
            
            # Calculate Loss
            # Combine BCE and Dice Loss
            bce_loss = lossfunc(pred, query_masks)
            
            # Initialize Dice Loss
            if not hasattr(net, 'dice_loss_fn'):
                net.dice_loss_fn = DiceLoss()
                
            dice_loss = net.dice_loss_fn(pred, query_masks)
            
            loss = bce_loss + dice_loss
            
            # Backprop
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
            
            pbar.update()
            pbar.set_postfix({'loss': loss.item(), 'bce': bce_loss.item(), 'dice': dice_loss.item()})
            epoch_loss += loss.item()
            
            # Visualization (Optional, every few steps)
            if ind % 100 == 0:
                 vis_image(query_imgs, pred, query_masks, os.path.join(args.path_helper['sample_path'], f'epoch{epoch}_batch{ind}.png'), reverse=False, points=None)

    return epoch_loss / len(train_loader)


def validation_sam(args, val_loader, epoch, net, writer, support_loader=None):
    # Validation using 1-shot mechanism
    # If support_loader is provided, use it to extract support features.
    # Otherwise, use the first batch of val_loader (Test set) as support (Standard One-Shot setting in some papers).
    # Ideally, support should come from Training set (Source) or a small labeled set in Target.
    
    torch.autocast(device_type="cuda", dtype=torch.bfloat16).__enter__()
    net.eval()
    
    # Metrics
    tol, eiou, edice = 0, 0, 0
    total_samples = 0
    
    # Memory Bank
    memory_bank_list = []
    feat_sizes = [(256, 256), (128, 128), (64, 64)]
    
    support_processed = False
    
    with torch.no_grad():
        # --- 1. Process Support ---
        if support_loader is not None:
            # Use explicit support loader (e.g. Training set of DRIS or REFUGE)
            # Take one batch
            try:
                pack = next(iter(support_loader))
                imgs = pack['image'].to(dtype = mask_type, device = GPUdevice)
                masks = pack['mask'].to(dtype = mask_type, device = GPUdevice)
                
                # CRITICAL FIX: Binarize Support Mask
                masks = (masks > 0.5).float()
                
                # Encode Support
                backbone_out = net.forward_image(imgs)
                _, vision_feats, vision_pos_embeds, _ = net._prepare_backbone_features(backbone_out)
                
                maskmem_features, maskmem_pos_enc = net._encode_new_memory(
                    current_vision_feats=vision_feats,
                    feat_sizes=feat_sizes,
                    pred_masks_high_res=masks,
                    is_mask_from_pts=True
                )
                
                B = imgs.size(0)
                feats = [feat.permute(1, 2, 0).view(B, -1, *feat_size) 
                         for feat, feat_size in zip(vision_feats[::-1], feat_sizes[::-1])][::-1]
                image_embed = feats[-1]

                maskmem_features = maskmem_features.to(torch.bfloat16).to(device=GPUdevice, non_blocking=True)
                maskmem_pos_enc = maskmem_pos_enc[0].to(torch.bfloat16).to(device=GPUdevice, non_blocking=True)

                # Store ONE memory (first sample)
                memory_bank_list.append([
                    maskmem_features[0].unsqueeze(0).detach(), 
                    maskmem_pos_enc[0].unsqueeze(0).detach(),
                    torch.tensor(1.0, device=GPUdevice),
                    image_embed[0].reshape(-1).detach()
                ])
                support_processed = True
            except StopIteration:
                print("Warning: Support loader is empty.")
                return 0, (0, 0)
        
        # --- 2. Validation Loop ---
        for ind, pack in enumerate(tqdm(val_loader, desc='Validation (1-Shot)', unit='img')):
            imgs = pack['image'].to(dtype = mask_type, device = GPUdevice)
            masks = pack['mask'].to(dtype = mask_type, device = GPUdevice)
            name = pack['image_meta_dict']['filename_or_obj']
            
            # If no explicit support loader, use first batch of val_loader as support
            if not support_processed and support_loader is None:
                # Use this image as Support
                backbone_out = net.forward_image(imgs)
                _, vision_feats, vision_pos_embeds, _ = net._prepare_backbone_features(backbone_out)
                
                # CRITICAL FIX: Binarize Support Mask
                masks_binary = (masks > 0.5).float()

                # Use GT mask for memory
                maskmem_features, maskmem_pos_enc = net._encode_new_memory(
                    current_vision_feats=vision_feats,
                    feat_sizes=feat_sizes,
                    pred_masks_high_res=masks_binary,
                    is_mask_from_pts=True
                )
                
                # Store in memory bank
                B = imgs.size(0)
                
                # Get image embed for attention
                feats = [feat.permute(1, 2, 0).view(B, -1, *feat_size) 
                         for feat, feat_size in zip(vision_feats[::-1], feat_sizes[::-1])][::-1]
                image_embed = feats[-1]

                maskmem_features = maskmem_features.to(torch.bfloat16).to(device=GPUdevice, non_blocking=True)
                maskmem_pos_enc = maskmem_pos_enc[0].to(torch.bfloat16).to(device=GPUdevice, non_blocking=True)

                # Store ONE memory
                memory_bank_list.append([
                    maskmem_features[0].unsqueeze(0).detach(), # [1, C, H, W]
                    maskmem_pos_enc[0].unsqueeze(0).detach(),
                    torch.tensor(1.0, device=GPUdevice),
                    image_embed[0].reshape(-1).detach()
                ])
                
                support_processed = True
                continue # Skip evaluation for the support image itself

            # --- Process Query ---
            
            # Image Encoder
            backbone_out = net.forward_image(imgs)
            _, vision_feats, vision_pos_embeds, _ = net._prepare_backbone_features(backbone_out)
            
            # Memory Attention
            # Use the stored memory
            to_cat_memory = [memory_bank_list[0][0].cuda(non_blocking=True).flatten(2).permute(2, 0, 1)]
            to_cat_memory_pos = [memory_bank_list[0][1].cuda(non_blocking=True).flatten(2).permute(2, 0, 1)]
            
            # memory = torch.stack(to_cat_memory, dim=0).squeeze(1) # [L, C] -> [L, 1, C] -> [L, C]? No.
            # Stack dim 0 -> [1, 1, C, H, W] (if list len 1) -> flatten -> [1, 1, 4096, 64] ?
            
            # Let's just follow previous logic:
            # memory_bank_list[0][0] is [1, 64, 64, 64]
            # flatten(2) -> [1, 64, 4096]
            # permute(2, 0, 1) -> [4096, 1, 64] (L, B, C)
            
            memory = memory_bank_list[0][0].cuda(non_blocking=True).flatten(2).permute(2, 0, 1) # [4096, 1, 64]
            memory_pos = memory_bank_list[0][1].cuda(non_blocking=True).flatten(2).permute(2, 0, 1)
            
            # Expand memory for current batch size B
            B = imgs.size(0)
            memory = memory.expand(-1, B, -1) # [4096, B, 64]
            memory_pos = memory_pos.expand(-1, B, -1)
            
            vision_feats[-1] = net.memory_attention(
                curr=[vision_feats[-1]],
                curr_pos=[vision_pos_embeds[-1]],
                memory=memory,
                memory_pos=memory_pos,
                num_obj_ptr_tokens=0
            )
            
            # Prompt Encoder
            # Use prompts if available (Click) or None
            if 'pt' in pack:
                pt_temp = pack['pt'].to(device = GPUdevice)
                pt = pt_temp.unsqueeze(1)
                point_labels_temp = pack['p_label'].to(device = GPUdevice)
                point_labels = point_labels_temp.unsqueeze(1)
                coords_torch = torch.as_tensor(pt, dtype=torch.float, device=GPUdevice)
                labels_torch = torch.as_tensor(point_labels, dtype=torch.int, device=GPUdevice)
                points = (coords_torch, labels_torch)
            else:
                points = None

            se, de = net.sam_prompt_encoder(
                points=points,
                boxes=None,
                masks=None,
                batch_size=B,
            )
            
            # Mask Decoder
            feats = [feat.permute(1, 2, 0).view(B, -1, *feat_size) 
                     for feat, feat_size in zip(vision_feats[::-1], feat_sizes[::-1])][::-1]
            image_embed = feats[-1]
            high_res_feats = feats[:-1]
            
            low_res_multimasks, iou_predictions, sam_output_tokens, object_score_logits = net.sam_mask_decoder(
                image_embeddings=image_embed,
                image_pe=net.sam_prompt_encoder.get_dense_pe(),
                sparse_prompt_embeddings=se,
                dense_prompt_embeddings=de,
                multimask_output=False,
                repeat_image=False,
                high_res_features=high_res_feats
            )
            
            # Prediction
            pred = F.interpolate(low_res_multimasks, size=(args.out_size, args.out_size))
            
            # Evaluate
            # Use 0.5 threshold
            threshold = (0.1, 0.3, 0.5, 0.7, 0.9)
            
            # [DEBUG] Print points for first batch
            if ind == 0 and points is not None:
                 print(f"[DEBUG] Validation Batch 0 Points: {points[0]}")
            
            # eval_seg returns different tuples based on channel count
            # Our masks are [B, 1, H, W] for DRIS (Single class: Cup)
            # So eval_seg returns (eiou, edice)
            
            # Check mask channels
            c = masks.size(1)
            
            if c == 2:
                 iou_d, iou_c, disc_dice, cup_dice = eval_seg(pred, masks, threshold)
                 tol += (disc_dice + cup_dice) / 2.0
                 eiou += (iou_d + iou_c) / 2.0
                 edice += (disc_dice + cup_dice) / 2.0
            else:
                 # Single class (Cup only) or Multi > 2
                 # eval_seg returns (eiou, edice) for c=1 (else branch)
                 res = eval_seg(pred, masks, threshold)
                 if len(res) == 2:
                     batch_iou, batch_dice = res
                     tol += batch_dice
                     eiou += batch_iou
                     edice += batch_dice
                 elif len(res) == 4:
                     # Just in case
                     iou_d, iou_c, disc_dice, cup_dice = res
                     tol += (disc_dice + cup_dice) / 2.0
                     eiou += (iou_d + iou_c) / 2.0
                     edice += (disc_dice + cup_dice) / 2.0
            
            total_samples += 1
            
    if total_samples == 0:
        return 0, (0, 0)
        
    return tol/total_samples, (eiou/total_samples, edice/total_samples)
