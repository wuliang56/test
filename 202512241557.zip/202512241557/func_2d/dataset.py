""" train and test dataset
Revised for One-Shot Domain Adaptation
"""
import os
import random
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import Dataset
from func_2d.utils import random_click, FDA_source_to_target

class REFUGE_FewShot(Dataset):
    def __init__(self, args, data_path, transform=None, transform_msk=None, mode='Training', prompt='click', plane=False):
        self.data_path = data_path
        # 获取所有子文件夹路径
        # Check if directory exists
        target_dir = os.path.join(data_path, mode + '-400')
        if not os.path.exists(target_dir):
             print(f"Warning: {target_dir} does not exist. REFUGE_FewShot might fail.")
             self.subfolders = []
        else:
             self.subfolders = [f.path for f in os.scandir(target_dir) if f.is_dir()]
             
        self.mode = mode
        self.prompt = prompt
        self.img_size = args.image_size
        self.mask_size = args.out_size
        
        # 注意：这里我们主要用 args 里的参数，transform 建议在 getitem 里做
        # 否则很难保证 Image 和 Mask 的同步变换
        self.transform = transform 
        self.transform_msk = transform_msk

        # Pre-load one DRIS reference image for FDA (Optional)
        # We need a path to a DRIS image.
        # Let's try to find one dynamically or hardcode one for simplicity
        self.fda_reference = None
        try:
             # Assume DRIS path structure relative to REFUGE or absolute
             dris_base = data_path.replace('REFUGE', 'DRIS')
             # Or use the path user mentioned: /root/autodl-tmp/DSM-main/data/DRIS
             if not os.path.exists(dris_base):
                  dris_base = '/root/autodl-tmp/DSM-main/data/DRIS'
             
             # Try to find an image in DRIS Test set
             test_imgs_base_dir = os.path.join(dris_base, 'Test-20211018T060000Z-001/Test/Images')
             if os.path.exists(test_imgs_base_dir):
                 candidate_images = []
                 for sub_dir_name in ['glaucoma', 'normal']:
                     sub_dir_path = os.path.join(test_imgs_base_dir, sub_dir_name)
                     if os.path.isdir(sub_dir_path):
                         for fname in os.listdir(sub_dir_path):
                             if fname.lower().endswith(('.png', '.jpg', '.jpeg')):
                                 candidate_images.append(os.path.join(sub_dir_path, fname))
                 
                 if candidate_images:
                     ref_img_path = random.choice(candidate_images)
                     self.fda_reference = Image.open(ref_img_path).convert('RGB')
                     self.fda_reference = self.fda_reference.resize((self.img_size, self.img_size))
                     print(f"FDA enabled: Using reference image from {ref_img_path}")
                 else:
                     # Fallback if no images found in expected subdirs
                     print(f"FDA disabled: No images found in subdirectories of {test_imgs_base_dir}")
             else:
                print(f"FDA disabled: DRIS test image directory not found at {test_imgs_base_dir}")
        except Exception as e:
             print(f"FDA disabled: Could not load reference image: {e}")

    def __len__(self):
        return len(self.subfolders)

    def load_single_sample(self, index, transform_seed=None, apply_fda=False):
        """辅助函数：读取单张样本"""
        subfolder = self.subfolders[index]
        name = os.path.basename(subfolder) # 兼容 Linux/Windows

        # 路径构建
        img_path = os.path.join(subfolder, name + '_cropped.jpg')
        # REFUGE 有多个 rater，这里我们直接读合并后的 mask 或者取平均
        # 为了简化，我们假设逻辑是取平均
        multi_rater_cup_path = [os.path.join(subfolder, name + '_seg_cup_' + str(i) + '_cropped.jpg') for i in range(1, 8)]

        # 读取
        img_pil = Image.open(img_path).convert('RGB')
        multi_rater_cup_pil = [Image.open(path).convert('L') for path in multi_rater_cup_path]
        
        # Apply FDA (before transform, on PIL image converted to numpy)
        if apply_fda and self.fda_reference is not None:
             # FDA expects numpy arrays [C, H, W] or [H, W, C]?
             # Our FDA function expects [C, H, W] if tensor, or numpy... let's check utils.py
             # It does fft2 on axes (-2, -1). So expects [..., H, W].
             # PIL -> Numpy is [H, W, C]. We need to transpose.
             
             img_np = np.array(img_pil.resize((self.img_size, self.img_size))).transpose(2, 0, 1) # [C, H, W]
             ref_np = np.array(self.fda_reference).transpose(2, 0, 1)
             
             # Random beta L
             L = random.uniform(0.01, 0.1) 
             img_fda = FDA_source_to_target(img_np, ref_np, L=L)
             
             # Convert back to PIL for consistency with transform pipeline
             # img_fda is numpy float, possibly 0-255.
             img_fda = img_fda.transpose(1, 2, 0).astype(np.uint8)
             img_pil = Image.fromarray(img_fda)

        
        # === 关键：同步变换 Image 和 Mask ===
        # 如果外部传入了 transform，我们需要小心控制 seed
        if self.transform:
            if transform_seed is not None:
                torch.manual_seed(transform_seed)
                random.seed(transform_seed)
                
            # 保存状态以保证 Mask 和 Image 变换一致
            state = torch.get_rng_state()
            img = self.transform(img_pil)
            
            # 恢复状态给 Mask 用
            torch.set_rng_state(state)
            # 注意：Mask 不能被 Normalize！通常 self.transform_msk 应该只负责 Resize/ToTensor
            # 如果没有专门的 transform_msk，这里需要手动处理
            if self.transform_msk:
                multi_rater_cup = [self.transform_msk(rater) for rater in multi_rater_cup_pil]
            else:
                # 简单兜底：Resize + ToTensor (假设 img 也是 Resize 到了 img_size)
                # 这里假设 img 已经是 Tensor [3, H, W]
                multi_rater_cup = []
                for rater in multi_rater_cup_pil:
                    rater = rater.resize((self.img_size, self.img_size), Image.NEAREST)
                    t_rater = torch.tensor(np.array(rater), dtype=torch.float32) / 255.0
                    multi_rater_cup.append(t_rater.unsqueeze(0)) # [1, H, W]
                
            multi_rater_cup = torch.stack(multi_rater_cup, dim=0) # [7, 1, H, W]
        else:
            # 如果没有 transform，直接转 tensor
            img = torch.tensor(np.array(img_pil.resize((self.img_size, self.img_size))).transpose(2,0,1)).float() / 255.0
            multi_rater_cup = torch.stack([torch.tensor(np.array(r.resize((self.img_size, self.img_size)))).float().unsqueeze(0)/255.0 for r in multi_rater_cup_pil], dim=0)

        # 生成 GT Mask (Majority Vote)
        # multi_rater_cup shape: [7, 1, H, W]
        mask_ori = multi_rater_cup.mean(dim=0) # [1, H, W]
        mask_binary = (mask_ori >= 0.5).float()
        
        # Resize 到输出尺寸 (如 256) 给 Memory Encoder 用
        mask_out = F.interpolate(mask_binary.unsqueeze(0), size=(self.mask_size, self.mask_size), mode='nearest').squeeze(0)
        
        return img, mask_out, name, mask_binary

    def __getitem__(self, index):
        # 1. 获取 Query (Target) - 当前索引
        # 给一个随机种子确保 mask 和 img 对齐
        seed_q = random.randint(0, 2**32)
        
        # Apply FDA to Query image with 50% probability?
        # Or apply to both?
        # Usually we want Query to look like Target Domain (DRIS).
        # Support is from Source Domain (REFUGE).
        # But wait, if Support is REFUGE style and Query is DRIS style, 
        # the model learns to match across domains. THIS IS EXACTLY WHAT WE WANT.
        # So: Apply FDA to Query ONLY (or with high prob).
        
        apply_fda_q = random.random() < 0.5
        q_img, q_mask, q_name, q_mask_ori = self.load_single_sample(index, seed_q, apply_fda=apply_fda_q)
        
        # 2. 获取 Support (Reference) - 随机另一个索引
        # === 核心修改：真正的 Pairwise ===
        s_index = random.randint(0, len(self.subfolders) - 1)
        while s_index == index: # 确保不是同一张
             s_index = random.randint(0, len(self.subfolders) - 1)
        
        seed_s = random.randint(0, 2**32)
        # Support usually stays in Source Domain style (REFUGE) because that's what we have labeled in memory?
        # Or should we augment Support too? 
        # If we augment Support to be DRIS-like, then it's DRIS-to-DRIS matching.
        # If we keep Support as REFUGE, it's REFUGE-to-DRIS matching.
        # Let's keep Support as REFUGE (no FDA) to simulate the real inference scenario:
        # Wait, in inference we use DRIS support for DRIS query (1-shot within target domain).
        # But our training goal is to make the features invariant.
        # Let's randomly apply FDA to Support too, to simulate various gaps.
        
        apply_fda_s = random.random() < 0.3
        s_img, s_mask, s_name, _ = self.load_single_sample(s_index, seed_s, apply_fda=apply_fda_s)
        
        # 3. 构造 Prompt (仅针对 Query)
        # REFUGE 原逻辑：随机点提示
        # q_mask_ori [1, H, W]
        point_label, pt = random_click(np.array(q_mask_ori.squeeze(0)), point_label=1)

        image_meta_dict = {'filename_or_obj': q_name}
        
        return {
            'support_image': s_img,     # [3, H, W]
            'support_mask': s_mask,     # [1, H, W] (For Memory)
            'query_image': q_img,       # [3, H, W]
            'query_mask': q_mask,       # [1, H, W] (For Loss)
            'query_p_label': point_label,
            'query_pt': pt,
            'image_meta_dict': image_meta_dict,
        }

# DRIS 类保持你原来的逻辑，但我修补了 Mask Transform 的 bug
class DRIS(Dataset):
    def __init__(self, args, data_path, transform=None, transform_msk=None, mode='Training', prompt='click', plane=False):
        self.data_path = data_path
        self.mode = mode
        self.prompt = prompt
        self.img_size = args.image_size
        self.mask_size = args.out_size
        self.transform = transform
        self.transform_msk = transform_msk # 确保这个不包含 Normalize
        self.image_paths = []

        # ... (路径加载逻辑保持不变) ...
        # [代码省略，直接用你原来写好的路径扫描部分即可]
        # ================= 1. 根据你的文件树构建路径 =================
        if 'train' in mode.lower():
            self.root_dir = os.path.join(data_path, 'Training-20211018T055246Z-001', 'Training')
            img_base = os.path.join(self.root_dir, 'Images')
            subfolders = ['GLAUCOMA', 'NORMAL'] 
        else:
            self.root_dir = os.path.join(data_path, 'Test-20211018T060000Z-001', 'Test')
            img_base = os.path.join(self.root_dir, 'Images')
            subfolders = ['glaucoma', 'normal'] 

        if os.path.exists(img_base):
            for sub in subfolders:
                full_sub_path = os.path.join(img_base, sub)
                if os.path.exists(full_sub_path):
                    imgs = [os.path.join(full_sub_path, f) for f in os.listdir(full_sub_path) if f.endswith('.png')]
                    self.image_paths.extend(imgs)
            self.image_paths.sort() 
            print(f"[{mode}] DRIS: Loaded {len(self.image_paths)} images from {img_base}")

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, index):
        img_path = self.image_paths[index]
        name = os.path.basename(img_path).split('.')[0]
        
        gt_folder_name = 'GT' if 'train' in self.mode.lower() else 'Test_GT'
        mask_path = os.path.join(self.root_dir, gt_folder_name, name, 'SoftMap', name + '_cupsegSoftmap.png')

        img_pil = Image.open(img_path).convert('RGB')
        
        if os.path.exists(mask_path):
            mask_pil = Image.open(mask_path).convert('L')
        else:
            print(f"Warning: Mask not found at {mask_path}. Using blank mask.")
            mask_pil = Image.new('L', img_pil.size, 0)

        # === 修复：分离 Mask 和 Image 的 Transform ===
        if self.transform:
            state = torch.get_rng_state()
            img = self.transform(img_pil) # Image 含 Normalize
            
            torch.set_rng_state(state) # 几何变换同步
            
            if self.transform_msk:
                mask = self.transform_msk(mask_pil)
            else:
                # 兜底：只做 Resize -> ToTensor
                mask_pil = mask_pil.resize((self.img_size, self.img_size), Image.NEAREST)
                mask = torch.tensor(np.array(mask_pil), dtype=torch.float32).unsqueeze(0) / 255.0
        else:
            img = torch.tensor(np.array(img_pil.resize((self.img_size, self.img_size))).transpose(2,0,1)).float() / 255.0
            mask_pil = mask_pil.resize((self.img_size, self.img_size), Image.NEAREST)
            mask = torch.tensor(np.array(mask_pil), dtype=torch.float32).unsqueeze(0) / 255.0

        mask = (mask >= 0.5).float()

        # Prompt 生成逻辑 (推荐使用质心)
        pt_cup = torch.tensor([self.img_size // 2, self.img_size // 2])
        point_label_cup = 0
        y_indices, x_indices = torch.where(mask.squeeze() > 0.5)
        
        if len(y_indices) > 0:
            point_label_cup = 1
            if self.prompt == 'click':
                # 使用质心
                center_y = int(torch.mean(y_indices.float()))
                center_x = int(torch.mean(x_indices.float()))
                pt_cup = torch.tensor([center_x, center_y]) 

        # Memory 需要的 Mask 输入尺寸
        mask_input = F.interpolate(mask.unsqueeze(0), size=(self.mask_size, self.mask_size), mode='nearest').squeeze(0)
        
        return {
            'image': img,
            'mask': mask_input, # [1, H, W]
            'mask_ori': mask.squeeze(),
            'p_label': point_label_cup,
            'pt': pt_cup, 
            'image_meta_dict': {'filename_or_obj': name},
        }