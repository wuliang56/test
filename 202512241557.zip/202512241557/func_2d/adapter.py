
import torch
import torch.nn as nn

class FeatureAdapter(nn.Module):
    def __init__(self, dim):
        super().__init__()
        # Simple Bottleneck Adapter: 1x1 Conv -> ReLU -> 1x1 Conv
        # Reduces dimension by 4, then restores it.
        self.adapter = nn.Sequential(
            nn.Conv2d(dim, dim // 4, kernel_size=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim // 4, dim, kernel_size=1, bias=False)
        )
        # Initialize last layer to zeros to act as identity initially
        nn.init.zeros_(self.adapter[-1].weight)
        
    def forward(self, x):
        # x shape: [Batch, Dim, H, W]
        # Residual connection
        return x + self.adapter(x)

class AdapterModel(nn.Module):
    def __init__(self, net=None): # Remove net dependency to avoid circular reference
        super().__init__()
        # self.net = net # REMOVE THIS
        
        # We need adapters for 32, 64, 256.
        self.adapters = nn.ModuleList([
            FeatureAdapter(32),
            FeatureAdapter(64),
            FeatureAdapter(256)
        ])
        
    # Remove forward_image as we call it on net directly
    
    def adapt_features(self, vision_feats):
        # Apply adapters to the extracted features
        # vision_feats is a list of 3 tensors [B, C, H, W] (channel-first?)
        # Wait, in function.py:
        # vision_feats[0]: torch.Size([65536, batch, 32]) -> [H*W, B, C]
        # BUT `_prepare_backbone_features` implementation in SAM2 usually returns [L, B, C].
        
        # HOWEVER, the Adapter (Conv2d) needs [B, C, H, W].
        # We need to reshape, adapt, and reshape back.
        
        adapted_feats = []
        for i, feat in enumerate(vision_feats):
            # feat: [L, B, C]
            L, B, C = feat.shape
            S = int(L**0.5) # Assuming square
            
            # [L, B, C] -> [B, C, H, W]
            feat_spatial = feat.permute(1, 2, 0).reshape(B, C, S, S)
            
            # Adapt
            feat_adapted = self.adapters[i](feat_spatial)
            
            # [B, C, H, W] -> [L, B, C]
            feat_out = feat_adapted.flatten(2).permute(2, 0, 1)
            adapted_feats.append(feat_out)
            
        return adapted_feats
